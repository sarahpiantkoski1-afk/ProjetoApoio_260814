<?php

return [
    'MAIL_HOST' => 'smtp.gmail.com',
    'MAIL_PORT' => 587,
    'MAIL_USERNAME' => 'apoiomais.oficial@gmail.com',
    'MAIL_PASSWORD' => 'khen yjez nlqv jzwv',
    'MAIL_ENCRYPTION' => 'tls',
    'MAIL_FROM_ADDRESS' => 'apoiomais.oficial@gmail.com',
    'MAIL_FROM_NAME' => 'Apoio+',
    'APP_URL' => 'http://localhost/ProjetoApoiofinal/ProjetoApoio/frontend/telas',
];
